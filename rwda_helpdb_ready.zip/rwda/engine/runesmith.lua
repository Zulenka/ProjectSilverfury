rwda = rwda or {}
rwda.engine = rwda.engine or {}
rwda.engine.runesmith = rwda.engine.runesmith or {}

local runesmith = rwda.engine.runesmith

-- ─────────────────────────────────────────────────────────────────────────────
-- State machine
-- ─────────────────────────────────────────────────────────────────────────────

-- States:
--   idle → sketching_baseline → sketching_core → empowering_weapon →
--          sketching_config → setting_priority → done
-- OR:
--   idle → sketching_gebu → sketching_gebo → empowering_armour → done
-- OR (configure-only):
--   idle → sketching_config → setting_priority → done

local sm = {
  state              = "idle",
  work_ref    = nil,   -- item reference string (e.g. "runeblade", "left", "armour")
  config_name = nil,   -- chosen preset name
  steps       = {},    -- { cmd, confirm, fail_patterns } ordered list
  step_index  = 0,
  _timer      = nil,
  verbose     = false, -- set true in-game with: lua rwda.engine.runesmith.setVerbose(true)
  -- lookup_empower state
  _lookup_phase      = nil,  -- "scanning" | "confirming" | nil
  _pending_empower_id = nil, -- item ID discovered from II output
}

-- ─────────────────────────────────────────────────────────────────────────────
-- Internal helpers
-- ─────────────────────────────────────────────────────────────────────────────

local function cfg()
  return (rwda.config and rwda.config.runesmith) or {}
end

local function log(fmt, ...)
  if rwda.util and rwda.util.log then
    rwda.util.log("info", "[Runesmith] " .. fmt, ...)
  end
end

local function warn(fmt, ...)
  if rwda.util and rwda.util.log then
    rwda.util.log("warn", "[Runesmith] " .. fmt, ...)
  end
end

local function sendGame(cmd)
  if type(send) == "function" then
    send(cmd)
  end
end

local function cancelTimer()
  if sm._timer and type(killTimer) == "function" then
    pcall(killTimer, sm._timer)
  end
  sm._timer = nil
end

-- Catch-all Mudlet line trigger — alive only during an active workflow.
-- This is the primary delivery path because sysDataReceived can be unreliable
-- depending on other packages installed in the Mudlet session.
local function cancelLineTrigger()
  if runesmith._line_trigger and type(killTrigger) == "function" then
    pcall(killTrigger, runesmith._line_trigger)
    runesmith._line_trigger = nil
  end
end

local function registerLineTrigger()
  cancelLineTrigger()  -- kill any stale one first
  if type(tempRegexTrigger) == "function" then
    runesmith._line_trigger = tempRegexTrigger(".", function()
      runesmith.onLine(line)  -- `line` is the Mudlet trigger global
    end)
  end
end

local function emit(name, payload)
  if rwda.engine and rwda.engine.events and rwda.engine.events.emit then
    rwda.engine.events.emit(name, payload)
  end
end

-- ─────────────────────────────────────────────────────────────────────────────
-- Step runner
-- ─────────────────────────────────────────────────────────────────────────────

local function advanceStep()
  sm.step_index = sm.step_index + 1
  if sm.step_index > #sm.steps then
    runesmith.complete()
    return
  end

  local step = sm.steps[sm.step_index]
  sm.state = step.state_name or "working"

  -- For lookup_empower steps, send II first to discover the item ID.
  if step.type == "lookup_empower" then
    sm._lookup_phase      = "scanning"
    sm._pending_empower_id = nil
    log("Step %d/%d: II (looking up item ID for hand='%s')", sm.step_index, #sm.steps, tostring(step.hand))
    sendGame("II")
  else
    log("Step %d/%d: %s", sm.step_index, #sm.steps, step.cmd)
    sendGame(step.cmd)
  end
end

local function scheduleAdvance()
  cancelTimer()
  local delayMs = cfg().step_delay_ms or 800
  if type(tempTimer) == "function" then
    sm._timer = tempTimer(delayMs / 1000, function()
      sm._timer = nil
      advanceStep()
    end)
  else
    -- Fallback: immediate (no timer API in test context)
    advanceStep()
  end
end

-- ─────────────────────────────────────────────────────────────────────────────
-- Step builder helpers
-- ─────────────────────────────────────────────────────────────────────────────

local SKETCH_FAIL = {
  "You need more equilibrium",
  "you need more equilibrium",
  "You don't have any",
  "you don't have any",
  "You aren't holding",
  "you aren't holding",
  "That is not a runeblade",
  "that is not a runeblade",
  "You cannot sketch",
  "you cannot sketch",
}

local EMPOWER_FAIL = {
  "You need more equilibrium",
  "you need more equilibrium",
  "You don't have enough mana",
  "you don't have enough mana",
  "You cannot empower",
  "you cannot empower",
  "That is not a runeblade",
  "that is not a runeblade",
}

local function sketchStep(rune, ref, stateName)
  return {
    cmd        = string.format("sketch %s on %s", rune:lower(), ref),
    confirm    = string.format("you finish sketching a %s rune", rune:lower()),
    fail       = SKETCH_FAIL,
    state_name = stateName or ("sketching_" .. rune:lower()),
  }
end

local function empowerStep(ref, empower_ref, stateName)
  -- If empower_ref is a hand position ("left"/"right") or not provided,
  -- we must run II first to get the actual item ID, then empower by ID.
  -- If empower_ref is explicitly provided and not a hand word, use it directly.
  local hand = (empower_ref or ref or ""):lower()
  local is_hand_pos = (hand == "left" or hand == "right")
  local use_lookup  = is_hand_pos or (empower_ref == nil or empower_ref == "")

  if use_lookup then
    -- Determine which hand to scan in II output.
    local scan_hand = hand
    if not is_hand_pos then
      -- ref itself is a hand position
      scan_hand = (ref or ""):lower()
      if scan_hand ~= "left" and scan_hand ~= "right" then
        scan_hand = "left"  -- safe fallback
      end
    end
    return {
      type       = "lookup_empower",
      cmd        = "II",
      hand       = scan_hand,
      -- Achaea prints multi-line text; this phrase is unique to successful empower.
      confirm    = "as the flames fade",
      fail       = EMPOWER_FAIL,
      state_name = stateName or "empowering",
    }
  else
    -- Caller supplied explicit item ID / name (e.g. "scimitar228403").
    return {
      cmd        = string.format("empower %s", empower_ref),
      confirm    = "as the flames fade",
      fail       = EMPOWER_FAIL,
      state_name = stateName or "empowering",
    }
  end
end

local function configStep(ref, runes, stateName)
  return {
    cmd        = string.format("sketch configuration %s %s", ref, table.concat(runes, " ")),
    confirm    = "you finish sketching the configuration",
    fail       = SKETCH_FAIL,
    state_name = stateName or "sketching_config",
  }
end

local function priorityStep(runes)
  return {
    cmd        = "empower priority set " .. table.concat(runes, " "),
    confirm    = "you set the empowerment priority",
    fail       = { "you cannot", "no rune" },
    state_name = "setting_priority",
  }
end

-- ─────────────────────────────────────────────────────────────────────────────
-- Step sequence builders
-- ─────────────────────────────────────────────────────────────────────────────

-- empower_ref: item keyword for the EMPOWER command (e.g. "scimitar").
--              Defaults to ref (works when ref IS the item name, e.g. armour).
--              Use separately when sketch ref is a hand position ("left"/"right").
local function buildWeaponSteps(ref, preset, empower_ref)
  local steps = {}

  -- 1. Baseline weapon runes (lagul, lagua, laguz)
  for _, r in ipairs(preset.weapon_runes or { "lagul", "lagua", "laguz" }) do
    steps[#steps + 1] = sketchStep(r, ref, "sketching_baseline")
  end

  -- 2. Empower weapon (locks in baseline, makes it a proper Runeblade)
  --    Core and config runes REQUIRE an already-empowered Runeblade.
  steps[#steps + 1] = empowerStep(ref, empower_ref, "empowering_weapon")

  -- 3. Core runeblade rune (must come AFTER empower)
  if preset.core_rune then
    steps[#steps + 1] = sketchStep(preset.core_rune, ref, "sketching_core")
  end

  -- 4. Configuration runes (if any)
  if preset.config_runes and #preset.config_runes > 0 then
    steps[#steps + 1] = configStep(ref, preset.config_runes, "sketching_config")
    steps[#steps + 1] = priorityStep(preset.config_runes)
  end

  return steps
end

local function buildArmourSteps(ref, empower_ref)
  return {
    sketchStep("gebu", ref, "sketching_gebu"),
    sketchStep("gebo", ref, "sketching_gebo"),
    empowerStep(ref, empower_ref, "empowering_armour"),
  }
end

local function buildConfigureSteps(ref, preset)
  if not preset.config_runes or #preset.config_runes == 0 then
    return {}
  end
  return {
    configStep(ref, preset.config_runes, "sketching_config"),
    priorityStep(preset.config_runes),
  }
end

-- ─────────────────────────────────────────────────────────────────────────────
-- Completion and failure
-- ─────────────────────────────────────────────────────────────────────────────

function runesmith.complete()
  cancelTimer()
  cancelLineTrigger()
  sm._lookup_phase       = nil
  sm._pending_empower_id = nil
  sm.state = "done"
  local preset = sm.config_name and rwda.data and rwda.data.rune_configs and rwda.data.rune_configs.get(sm.config_name)
  log("Workflow complete for '%s' using preset '%s'.", tostring(sm.work_ref), tostring(sm.config_name or "armour"))

  -- Auto-sync runelore config
  if preset and not preset.armour and cfg().auto_sync_runelore ~= false then
    if rwda.config and rwda.config.runelore then
      rwda.config.runelore.default_core        = preset.core_rune
      rwda.config.runelore.default_config_runes = { table.unpack(preset.config_runes) }
      rwda.config.runelore.empower_priority     = { table.unpack(preset.config_runes) }
      if preset.bisect ~= nil then
        rwda.config.runelore.bisect_enabled = preset.bisect
      end
      log("Runelore config synced: core=%s config=%s", tostring(preset.core_rune), table.concat(preset.config_runes, ","))
    end
    -- Also update live runeblade state if loaded
    if rwda.state and rwda.state.runeblade then
      if rwda.state.runeblade.setConfiguration then
        rwda.state.runeblade.setConfiguration(preset.core_rune, preset.config_runes)
      end
      if rwda.state.runeblade.setEmpowerPriority then
        rwda.state.runeblade.setEmpowerPriority(preset.config_runes)
      end
    end
  end

  -- Auto-apply kelp_cycle from preset to venom planner
  if preset and preset.kelp_cycle and #preset.kelp_cycle > 0 then
    if rwda.config and rwda.config.runewarden then
      rwda.config.runewarden.venoms = rwda.config.runewarden.venoms or {}
      rwda.config.runewarden.venoms.kelp_cycle = { table.unpack(preset.kelp_cycle) }
      log("Kelp venom cycle set to: %s", table.concat(preset.kelp_cycle, ", "))
    end
  end

  -- Auto-switch RWDA profile
  if preset and preset.profile_hint and cfg().auto_switch_profile ~= false then
    if rwda.state and rwda.state.flags then
      rwda.state.flags.profile = preset.profile_hint
      log("Profile switched to '%s'.", preset.profile_hint)
    end
  end

  log("Run: rwda save config   -- to persist this setup.")
  emit("RUNESMITH_DONE", { config_name = sm.config_name, ref = sm.work_ref })

  -- Reset
  sm.config_name = nil
  sm.work_ref    = nil
  sm.steps       = {}
  sm.step_index  = 0
end

function runesmith.fail(reason)
  cancelTimer()
  cancelLineTrigger()
  sm._lookup_phase       = nil
  sm._pending_empower_id = nil
  warn("Workflow FAILED at step %d/%d (%s): %s", sm.step_index, #sm.steps, sm.state, tostring(reason))
  emit("RUNESMITH_FAILED", { reason = reason, state = sm.state, step = sm.step_index })
  sm.state      = "idle"
  sm.steps      = {}
  sm.step_index = 0
end

-- ─────────────────────────────────────────────────────────────────────────────
-- Line handler (called by parser for every game line while active)
-- ─────────────────────────────────────────────────────────────────────────────

function runesmith.onLine(line)
  if sm.state == "idle" or sm.state == "done" or #sm.steps == 0 then return end
  if not line then return end

  local lower = line:lower()
  local step  = sm.steps[sm.step_index]
  if not step then return end

  if sm.verbose then
    log("[onLine] state=%s step=%d phase=%s line=%q", sm.state, sm.step_index, tostring(sm._lookup_phase), line)
  end

  -- ── lookup_empower: two-phase step ──────────────────────────────────────
  -- Phase 1 "scanning": we sent II; read hand-position lines to get the item ID.
  -- Phase 2 "confirming": we sent empower <id>; wait for the ritual confirm.
  if step.type == "lookup_empower" then
    if sm._lookup_phase == "scanning" then
      -- II output format:  "   Left hand:  scimitar228403      a Scimitar of Eagles"
      local hand = (step.hand or "left"):lower()
      local id = lower:match(hand .. " hand:%s*(%S+)")
      if id then
        sm._pending_empower_id = id
        sm._lookup_phase = "confirming"
        log("Step %d: found item ID=%s, sending: empower %s", sm.step_index, id, id)
        sendGame("empower " .. id)
      end
      -- Keep scanning until we find the line (don't advance yet).
      return
    elseif sm._lookup_phase == "confirming" then
      -- Check fail patterns first.
      for _, pat in ipairs(step.fail or {}) do
        if lower:find(pat:lower(), 1, true) then
          runesmith.fail(pat)
          return
        end
      end
      -- Success: the empower ritual completion phrase.
      if lower:find(step.confirm, 1, true) then
        local empowered_id = sm._pending_empower_id
        log("Step %d: empower confirmed (item=%s)", sm.step_index, tostring(empowered_id))
        sm._lookup_phase       = nil
        sm._pending_empower_id = nil
        emit("RUNESMITH_STEP_DONE", { step = sm.step_index, cmd = "empower " .. tostring(empowered_id) })
        scheduleAdvance()
      end
      return
    end
    -- Unexpected: fall through to normal handling.
  end

  -- ── Normal step handling ─────────────────────────────────────────────────
  -- Check confirm
  if lower:find(step.confirm, 1, true) then
    log("Step %d confirmed: %q", sm.step_index, step.cmd)
    emit("RUNESMITH_STEP_DONE", { step = sm.step_index, cmd = step.cmd })
    scheduleAdvance()
    return
  end

  -- Rune already present — treat as success and advance.
  -- Matches any variant: "There is no need to duplicate runes."
  if lower:find("no need to duplicate", 1, true)
    or lower:find("already sketched", 1, true)
    or lower:find("rune already exists", 1, true) then
    log("Step %d: rune already present (%q), skipping.", sm.step_index, line)
    emit("RUNESMITH_STEP_DONE", { step = sm.step_index, cmd = step.cmd })
    scheduleAdvance()
    return
  end

  -- Check fail patterns
  for _, pat in ipairs(step.fail or {}) do
    if lower:find(pat:lower(), 1, true) then
      runesmith.fail(pat)
      return
    end
  end
end

--- Toggle verbose line logging (useful for diagnosing what lines arrive while active).
function runesmith.setVerbose(flag)
  sm.verbose = flag == true
  log("Verbose %s.", sm.verbose and "ON" or "OFF")
end

-- ─────────────────────────────────────────────────────────────────────────────
-- Public workflow entry points
-- ─────────────────────────────────────────────────────────────────────────────

--- Full weapon build: sketch baseline runes → EMPOWER → core → CONFIGURATION.
--- ref:         item keyword used for SKETCH commands (e.g. "left", "right", "scimitar")
--- configName:  preset name
--- empower_ref: item keyword for the EMPOWER command (e.g. "scimitar").
---              Defaults to ref. Required when ref is a hand position ("left"/"right").
function runesmith.beginWeapon(ref, configName, empower_ref)
  if sm.state ~= "idle" and sm.state ~= "done" then
    warn("Already running a workflow (state=%s). Cancel first.", sm.state)
    return false
  end

  local preset = rwda.data and rwda.data.rune_configs and rwda.data.rune_configs.get(configName)
  if not preset then
    warn("Unknown preset '%s'. Use: rwda runesmith list", tostring(configName))
    return false
  end
  if preset.armour then
    warn("Preset '%s' is an armour preset. Use: rwda runesmith armour <ref>", configName)
    return false
  end

  empower_ref = (empower_ref and empower_ref ~= "") and empower_ref or ref
  sm.work_ref    = ref
  sm.config_name = configName
  sm.steps       = buildWeaponSteps(ref, preset, empower_ref)
  sm.step_index  = 0

  local inkStr = rwda.data.rune_configs.inkCostString(configName)
  log("Starting weapon workflow: ref='%s' empower='%s' preset='%s' steps=%d ink=%s",
    ref, empower_ref, configName, #sm.steps, inkStr)
  registerLineTrigger()
  scheduleAdvance()
  return true
end

--- Armour empowerment: sketch Gebu + Gebo → EMPOWER.
--- ref/empower_ref: usually the same (the armour item keyword).
function runesmith.beginArmour(ref, empower_ref)
  if sm.state ~= "idle" and sm.state ~= "done" then
    warn("Already running a workflow (state=%s). Cancel first.", sm.state)
    return false
  end

  empower_ref = (empower_ref and empower_ref ~= "") and empower_ref or ref
  sm.work_ref    = ref
  sm.config_name = nil
  sm.steps       = buildArmourSteps(ref, empower_ref)
  sm.step_index  = 0

  log("Starting armour workflow: ref='%s' empower='%s' steps=%d ink=2G", ref, empower_ref, #sm.steps)
  registerLineTrigger()
  scheduleAdvance()
  return true
end

--- Configuration-only: for an already-empowered runeblade.
--- Sends SKETCH CONFIGURATION + EMPOWER PRIORITY SET only.
function runesmith.beginConfigure(ref, configName)
  if sm.state ~= "idle" and sm.state ~= "done" then
    warn("Already running a workflow (state=%s). Cancel first.", sm.state)
    return false
  end

  local preset = rwda.data and rwda.data.rune_configs and rwda.data.rune_configs.get(configName)
  if not preset then
    warn("Unknown preset '%s'. Use: rwda runesmith list", tostring(configName))
    return false
  end
  if preset.armour then
    warn("Preset '%s' is an armour preset. Use: rwda runesmith armour <ref>", configName)
    return false
  end

  sm.work_ref    = ref
  sm.config_name = configName
  sm.steps       = buildConfigureSteps(ref, preset)
  sm.step_index  = 0

  if #sm.steps == 0 then
    warn("Preset '%s' has no configuration runes defined.", configName)
    return false
  end

  log("Starting configure-only workflow: ref='%s' preset='%s' steps=%d", ref, configName, #sm.steps)
  registerLineTrigger()
  scheduleAdvance()
  return true
end

--- Abort any active workflow.
function runesmith.cancel()
  cancelTimer()
  cancelLineTrigger()
  sm._lookup_phase       = nil
  sm._pending_empower_id = nil
  if sm.state == "idle" then
    log("Nothing to cancel.")
    return
  end
  warn("Workflow cancelled at step %d/%d (state=%s).", sm.step_index, #sm.steps, sm.state)
  emit("RUNESMITH_FAILED", { reason = "cancelled", state = sm.state })
  sm.state      = "idle"
  sm.steps      = {}
  sm.step_index = 0
  sm.work_ref   = nil
  sm.config_name = nil
end

--- Print current state to the RWDA log.
function runesmith.status()
  if sm.state == "idle" then
    log("Idle — no active workflow.")
    return
  end
  local step = sm.steps[sm.step_index]
  log(
    "state=%s step=%d/%d ref='%s' preset='%s' next='%s'",
    sm.state,
    sm.step_index,
    #sm.steps,
    tostring(sm.work_ref   or "none"),
    tostring(sm.config_name or "armour"),
    step and step.cmd or "n/a"
  )
end

--- Return raw state-machine fields for external inspection / debugging.
-- Returns: state (string), step_index (int), total_steps (int), ref (string|nil), preset (string|nil)
function runesmith.getState()
  return sm.state, sm.step_index, #sm.steps, sm.work_ref, sm.config_name
end

--- Return the current step table (confirm/cmd) for debugging.
function runesmith.currentStep()
  return sm.steps[sm.step_index]
end

--- Bootstrap: register line listener, log init.
function runesmith.bootstrap()
  -- Register as a listener on the parser's DATA_LINE event if available.
  -- Parser also calls runesmith.onLine() directly from parser.lua.
  if rwda.engine and rwda.engine.events then
    rwda.engine.events.on("DATA_LINE", function(payload)
      runesmith.onLine(payload and payload.line)
    end)
  end

  -- Fallback direct Mudlet line trigger for the duplicate-rune message.
  -- NOTE: a broader catch-all trigger is now registered per-workflow in
  -- registerLineTrigger() (called by beginWeapon/beginArmour/beginConfigure).
  -- The bootstrap trigger below is kept as a last-resort for the specific
  -- duplicate message only, in case bootstrap runs before a workflow starts.
  if type(tempRegexTrigger) == "function" then
    -- Kill any prior registration (handles rwda reload without Mudlet restart).
    if runesmith._dup_trigger and type(killTrigger) == "function" then
      pcall(killTrigger, runesmith._dup_trigger)
      runesmith._dup_trigger = nil
    end
    -- Workflow catch-all (registerLineTrigger) supersedes this, so skip here.
    -- runesmith._dup_trigger = tempRegexTrigger(...)
  end

  log("Bootstrap complete (step_delay=%dms auto_sync_runelore=%s auto_switch_profile=%s)",
    cfg().step_delay_ms or 800,
    tostring(cfg().auto_sync_runelore ~= false),
    tostring(cfg().auto_switch_profile ~= false)
  )
end
