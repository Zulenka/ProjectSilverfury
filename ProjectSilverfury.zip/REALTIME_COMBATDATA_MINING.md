# Project Plan: Collecting Real-World Text Combat Logs From PvP Fights for Lua Combat Simulation

## Executive Summary

This project targets the acquisition of *raw, real-world text combat logs* from in-game PvP encounters occurring within the last four years (approximately 2022-02-28 to 2026-02-28, America/New_York), with a preference for logs involving **Runewarden** and **Dragon** roles/classes. In the context where “Runewarden” and “Dragon” are ambiguous across games, the closest high-signal match in today’s public log ecosystem is the text-MUD family operated by entity["company","Iron Realms Entertainment","mud publisher us"], especially entity["video_game","Achaea","text mud 1997"] where Runewarden is an official class and “Dragon” commonly refers to dragonform attained at high level (e.g., “Greater Dragon”). citeturn36search4turn36search0

Because these games do not generally expose a single “official downloadable PvP combatlog file” for public scraping, the most practical approach is a mixed strategy: (a) **public log archives** designed specifically for sharing text-game logs, and (b) **consented first-party capture** (players logging their own fights). A particularly relevant public source is entity["organization","Ada's HTML Pastebin","text-game log pastebin"], explicitly created to share text-game logs (mostly Achaea) and offering an API-assisted ingestion pathway. citeturn38search2turn12search1 A second useful community archive is entity["organization","nogfx.org logs","ire mud log archive"]. citeturn36search6

The deliverable below is a **Markdown project plan** covering: prioritized sources, collection methodology, legal/ethical constraints, a parsing + normalization pipeline (with regex/pattern examples), a concrete event schema, at least 10 real log snippets with metadata, and a Lua integration plan (event bus + function mapping), plus testing and timeline.

## Target Problem and Definitions

A “combat log” here means *verbatim text output* produced during live play, including prompts, system echoes, and combat lines, ideally with one or more of the following:

- **Timestamps per line** (e.g., `18:49:09.015 ...`, `00:25:15.358 ...`) and preserveable **event ordering** by line order or timestamp. citeturn26view0turn21view0  
- **Ability usage** markers (e.g., “You use …”, “X uses …”) and explicit **damage/healing numbers** (e.g., “Health Lost: 118”, “Health Gain: 819”). citeturn21view0turn39view0turn29search2  
- **Buff/defence and debuff/affliction markers** (e.g., “You have gained the … defence.” “Your … defence has been stripped.” “You are afflicted with …”). citeturn21view0turn39view0turn29search2  
- **Timing/latency indicators**, when present, either explicitly as “Ping” style data or implicitly via server-side action timers (e.g., “Equilibrium Used: 3.00 seconds”, “Balance Used: 0.90 seconds”). citeturn21view0turn29search2turn39view0  

Important ambiguity handling:

- **Runewarden**: an official class in Achaea with documented skillsets (Runelore/Weaponmastery/Chivalry) and rune/totem mechanics. citeturn36search4turn36search1  
- **Dragon**: in Achaea, commonly refers to dragonform gained after ascending to “Greater Dragon.” citeturn36search0  
- If your target “Dragon class” instead refers to other games (e.g., Dragonknight, Dragoon), keep the pipeline game-agnostic: treat “class/role” as optional metadata extracted where present, and store uncertainty explicitly (e.g., `class_confidence: low`).  

A key design decision is whether you normalize to **(A) a universal event layer** (damage/heal/status/apply/remove/resource snapshot) or **(B) retain per-game semantics**. This plan uses both: preserve raw logs, then parse into a universal event stream while retaining “original_text” and game-specific fields.

## Source Landscape and Prioritization

The constraints are largely set by what is (1) publicly accessible, (2) legally safe to reuse, and (3) rich enough to train/extrapolate combat behavior.

### Prioritized source families

| Priority | Source family | What you get | Why it matters | Key limitations / risks |
|---|---|---|---|---|
| Highest | Official protocol/metadata docs (IRE) | Structured signals you can capture alongside text logs (e.g., vitals, afflictions/defences modules, optional ping behavior) | Enables high-quality labels (state snapshots) to pair with noisy text | Docs are not the dataset; you must capture live data in-client citeturn36search5 |
| Highest | Player-captured logs (consented) | True PvP sequences, with exact client formatting used in practice | Best match to “training/extrapolating combat behavior” needs | Requires consent + careful privacy handling; ToS constraints apply citeturn41view0turn41view1 |
| High | Ada’s HTML Pastebin / bin content host | Large volumes of real client logs; often timestamped lines, damage/heal lines, affliction/defence changes; some logs embed explicit dates in headers | Purpose-built for sharing text-game logs; practical for initial corpus bootstrapping; includes an API-based ingestion pathway citeturn38search2turn12search1turn21view0turn39view0 | Public availability can be transient (pastes considered for deletion after ~180 days since last viewed); don’t scrape disallowed content; treat as “seed corpus,” not sole source citeturn38search2 |
| Medium | nogfx.org logs | Public duels/logs from IRE titles | Additional variety; often explicitly tagged by realm/type citeturn36search6 | Coverage can be sparse or older depending on game/realm; metadata varies citeturn1view0 |
| Medium | Official portal logs | Official “Game Logs” sections exist (e.g., organizational logs) | May provide context metadata in some cases | Often requires authentication; may not provide combat-line granularity citeturn36search7 |
| Lower | Forums / public Discord / social posts | One-off high-value fights + commentary context (build, match terms) | Can enrich labels (“why” behind actions) | Highest privacy risk; inconsistent formatting; consent and ToS must be respected citeturn41view0turn41view1 |

### Why GMCP matters (even though you asked for “actual text logs”)

For IRE games, **GMCP** is a standardized channel where the server sends structured JSON-like data to the client (e.g., character health, afflictions, defences), which you can capture in parallel to raw text logs for significantly cleaner state labeling. citeturn36search5 It also documents a ping mechanism (`Core.Ping`) that can act as a latency indicator in supported setups. citeturn36search5

## Collection Methodology

This methodology explicitly separates **seed acquisition** (quickly build a starter dataset from public logs) from **production acquisition** (generate a legally robust, well-labeled corpus suitable for ML training and simulation grounding).

### Seed acquisition from public log archives

1. **Enumerate candidate logs** within the past four years by searching for log headers that embed dates (e.g., “Nexus log - … - 2026-2-17” style headers) and for PvP indicators (“You use … on <player>”, “<player> uses … on you”). citeturn32search3turn32search1turn39view0turn21view0  
2. **Capture minimally sufficient metadata** from the log header (game, character, date) when present, and otherwise record `capture_date = unknown` while retaining the raw timestamped lines. citeturn39view0turn26view0  
3. **Preserve raw formats** as stored (HTML/ANSI, plain text) plus a normalized plaintext copy so your parser work is reproducible and reversible. (This is essential when color tags or client formatting encode meaning, such as affliction highlights.) citeturn38search2  

### Production acquisition via first-party logging (recommended for “training-grade” corpora)

1. **Recruit consenting players** (or use your own controlled accounts) to record PvP sessions. Ensure each participant understands what will be logged and how it will be stored and used. Achaea’s Terms of Service and Privacy Policy explicitly address user conduct, ownership/rights over service data, and monitoring/disclosure behavior; you should treat this as a high-stakes compliance area. citeturn41view0turn41view1  
2. **Standardize client settings** so outputs are comparable:
   - Enable per-line timestamps and consistent prompts (HP/MP/balance/equilibrium markers). Example real logs show timestamped lines and “balance/equilibrium used” timers, which are highly valuable for reconstructing action windows. citeturn21view0turn39view0turn29search2  
   - If using Mudlet-style logging, capture the *log session header* (start time, date, file name) when available; sample logs include explicit session start/end lines and fight descriptors. citeturn35search0  
3. **Capture GMCP alongside text**, when permitted and supported, storing both streams with a shared clock and sequence index. GMCP can provide clean labels for afflictions/defences/vitals; it also documents `Core.Ping` behavior for ping/latency features. citeturn36search5  

### Data minimization and privacy-by-design

Ada’s HTML Pastebin reiterates an acceptable-use posture of **not posting personal information** and related sensitive content. Your pipeline should adopt similar defaults even if your storage is private. citeturn38search2 In addition, Achaea’s Privacy Policy describes collection of personal information and in-game actions, reinforcing the need to avoid collecting unnecessary personal identifiers when building datasets. citeturn41view1

## Legal and Ethical Considerations

This section focuses on practical risk controls for building a dataset that is realistically usable.

### Terms-of-service constraints and IP posture

- Achaea’s Terms of Service frames access as a license and includes provisions about unacceptable conduct and ownership/rights relating to services and data, plus a broad license over user-submitted content and statements about company ownership of service data. Treat large-scale scraping, redistribution of full logs, and automated extraction as potentially sensitive without explicit permission. citeturn41view0  
- The Terms also note monitoring/preservation/disclosure of communications, which reinforces that logs may contain sensitive communications; avoid collecting tells/credits/payment/account identifiers, and implement filters/redaction. citeturn41view0turn41view1  

### Privacy and consent

- Achaea’s Privacy Policy describes collection of personal data (registration info), server log data (e.g., IP address), and in-game actions for statistical purposes; while this does not directly authorize your dataset creation, it underscores that identity-linked data exists in the ecosystem and must be handled carefully. citeturn41view1  
- If you are collecting logs from third parties, obtain **informed consent**, and store either (a) pseudonymized actor IDs or (b) hashed names with a salted mapping stored separately.

### Ethical constraints for public/community logs

- Even when logs are publicly posted, you should treat them as user-generated content where **republication** and **model training** may not match original intent. Use public logs primarily as **format exemplars** and as a seed corpus; for “production-scale” datasets, prefer consented capture.
- Respect community norms and site rules (e.g., paste bins’ acceptable use norms; deletion/expiration expectations). citeturn38search2  

## Data Extraction Pipeline, Parsing Rules, and Schema

### Dataflow diagram

```mermaid
flowchart TD
  A[Source: raw log files\nHTML/ANSI/TXT] --> B[Ingest\nDownload + decompress + checksum]
  B --> C[Normalize\nHTML->text, ANSI->text,\nnewline + encoding cleanup]
  C --> D[Segment\nfight boundaries + participants]
  D --> E[Parse lines\npatterns -> events]
  E --> F[Enrich\nactor/target resolution,\nresource snapshots,\nlatency features]
  F --> G[Store\nRaw logs + Parsed events\n(append-only)]
  G --> H[Lua integration fixtures\nreplay runner + validators]
```

### Parsing strategy (robust to heterogeneous client formats)

Your parser should be **multi-pass**:

- **Pass 1: framing + timestamps**
  - Detect timestamp prefix (`HH:MM:SS.mmm`, sometimes `HH:MM:SS`).
  - Assign `seq` (monotonic line index) so you can order events when timestamps collide.

- **Pass 2: classify line types**
  - Ability use lines (e.g., “You use X Y.” / “<name> uses X Y on you.”). citeturn21view0turn29search2  
  - Damage/heal numeric lines (e.g., “Health Lost: 118, poison, agile”; “Health Gain: 819”; “Health lost: 691 (physical cutting).”). citeturn21view0turn26view0turn39view0  
  - Status changes (afflictions/defences gained/stripped). citeturn29search2turn39view0turn21view0  
  - Resource/prompt snapshots (HP/MP and other gauges), which often embed both absolute and % values.

- **Pass 3: temporal enrichment**
  - Extract “Balance Used / Equilibrium Used” durations as cooldown/timing features. citeturn21view0turn39view0turn29search2  
  - If you capture GMCP, join `Char.Vitals` and `Char.Afflictions/Defences` snapshots to the nearest text line by time and seq. citeturn36search5  

### Regex / pattern examples (starter set)

> Use these as conceptual examples; in Lua you’ll typically implement “regex-like” matching via Lua patterns, or via a regex library if your runtime supports it.

```regex
# Timestamp (milliseconds)
^(?<ts>\d{2}:\d{2}:\d{2}\.\d{3})\s+

# “You use …” (skill + ability)
^(?<ts>\d{2}:\d{2}:\d{2}\.\d{3})\s+You use (?<skill>\w+)\s+(?<ability>[\w']+)

# Health Lost / Gain (two common variants)
Health\s+Lost:\s+(?<amount>\d+)(?:,\s*(?<dtype>[^,]+))?
Health\s+Gain:\s+(?<amount>\d+)

# Affliction application
You are afflicted with (?<aff>\w+)

# Defence gained/stripped
You have gained the (?<def>\w+) defence
Your (?<def>[\w\s]+) defence has been stripped
```

### Data schema

A single table is rarely enough. Use a **two-layer model**: raw log storage + parsed event storage.

| Entity | Key fields | Notes |
|---|---|---|
| `raw_log` | `log_id`, `game`, `source_uri`, `capture_date`, `format` (txt/html/ansi), `character_name` (optional), `sha256`, `raw_bytes_path`, `normalized_text_path` | Preserve original bytes for audit/replay. `capture_date` from headers when present. |
| `fight` | `fight_id`, `log_id`, `start_seq`, `end_seq`, `start_ts`, `end_ts`, `participants[]`, `context` (arena/map/room text), `match_type` (duel/skirmish/raid/unknown) | Segmentation can be heuristic (target set lines; “vs” headers; first damage event). |
| `event` | `event_id`, `fight_id`, `seq`, `ts`, `actor`, `target`, `etype` (DAMAGE/HEAL/CAST/APPLY_STATUS/REMOVE_STATUS/RESOURCE_SNAPSHOT/COOLDOWN/etc), `skill`, `ability`, `amount`, `damage_type`, `status_added[]`, `status_removed[]`, `resource_before/after`, `timing_used_ms`, `raw_line` | `raw_line` enables reversible debugging and model interpretability. |
| `latency_feature` | `event_id`, `core_ping_ms` (if captured), `server_timer_ms` (balance/equilibrium), `client_send_to_echo_ms` (if instrumented) | GMCP `Core.Ping` supports ping semantics; text timers support action windows. citeturn36search5turn21view0turn39view0 |

## Sample Extracted Logs

The following are **real log snippets** (kept short, verbatim) showing diverse formats that contain many of the attributes you listed: timestamps, abilities, damage/healing numbers, defences/afflictions, and action timing (“balance/equilibrium used”). The “Runewarden” and “Dragon” priority is addressed via an Achaea Runewarden example and compounding methodology guidance; additional examples use other IRE-role logs when Runewarden/Dragon are not present.

### Sample log index (10 examples)

| Sample | Game title | Server/region | Date/time evidence | Log format | Roles/classes observed | Abilities + numbers present | Buff/debuff signals | Latency/timing signals | Raw snippet (verbatim) | Source |
|---|---|---|---|---|---|---|---|---|---|---|
| S1 | Achaea | Global (region not specified) | Date not embedded; per-line time-of-day present | Timestamped lines + prompt snapshots | Opponent explicitly marked “Runewarden” | Damage numbers present | Afflictions present | Implicit via timestamps | `18:49:09.015 Health lost: 691 (physical cutting).` | citeturn26view0 |
| S2 | Achaea | Global (region not specified) | Explicit session start: Sat, 10 May 2025 | Mudlet log session header + timestamps | “Blademaster vs Arador[Infernal]” | Fight descriptor present | Not in snippet | Not in snippet | `Log session starting at 18:34:31 on Saturday, 10 May 2025.` | citeturn35search0 |
| S3 | Aetolia | Global (region not specified) | Header: 2025-11-20 | Nexus log format | Zealot vs Predator (from paste title) | Health Lost present | Afflictions present | Balance/equilibrium lines present | `00:25:15.358 Health Lost: 118, poison, agile` | citeturn21view0 |
| S4 | Aetolia | Global (region not specified) | Header: 2024-12-10 | Nexus log format | Not explicit in snippet | Health Lost/Gain present | Defence stripped/gained present | “Fury Balance Used” present | `21:16:01.390 Health Lost: 1264` | citeturn39view0 |
| S5 | Aetolia | Global (region not specified) | Header: 2025-11-16 | Nexus log format | Not explicit in snippet | Damage present | Affliction present | Balance used present | `12:14:55.891 Health Lost: 212, cutting, brute` | citeturn29search2 |
| S6 | Aetolia | Global (region not specified) | Header: 2025-6-16 | Nexus log format | Not explicit in snippet | Ability “Fury Halt” present | “Their Affs” marker present | Uses balance timers | `21:24:24.793 You use Fury Halt on Irra.` | citeturn29search3 |
| S7 | Aetolia | Global (region not specified) | Header: 2025-9-4 | Nexus log format | Not explicit in snippet | Resource snapshot present | Not in snippet | Not in snippet | `21:33:50.602 H:5995 M:3706 A:4900 ...` | citeturn29search1 |
| S8 | Aetolia | Global (region not specified) | Header: 2026-1-1 | Nexus log format | Not explicit in snippet | Equilibrium used present | Not in snippet | Equilibrium timing present | `15:06:20.915 Equilibrium Used: 4.00 seconds` | citeturn32search1 |
| S9 | Aetolia | Global (region not specified) | Header: 2026-1-14 | Nexus log format | Not explicit in snippet | Inventory/room lines (context) | Not in snippet | Not in snippet | `01:15:03.896 There are 3 panacea pills in a stack here.` | citeturn32search4 |
| S10 | Aetolia | Global (region not specified) | Header: 2026-2-17 | Nexus log format | Not explicit in snippet | Venom/attack prep line present | Not in snippet | Not in snippet | `00:11:55.172 LOB Zarranik : CURARE` | citeturn32search3 |

### Raw-text blocks (verbatim excerpts)

```text
18:49:09.015 Health lost: 691 (physical cutting).
```
Source: Achaea Runewarden-tagged opponent context (timestamped combat line). citeturn26view0

```text
Log session starting at 18:34:31 on Saturday, 10 May 2025.
```
Source: Mudlet log session header from “Harkon - Achaea profile” logging a duel. citeturn35search0

```text
00:25:15.358 Health Lost: 118, poison, agile
```
Source: Aetolia PvP log excerpt (Zealot vs Predator context). citeturn21view0

```text
21:16:01.390 Health Lost: 1264
```
Source: Aetolia log excerpt including repeated damage/heal cycles and Fury timers. citeturn39view0

```text
12:14:55.891 Health Lost: 212, cutting, brute
```
Source: Aetolia log excerpt showing attack damage type qualifiers. citeturn29search2

```text
21:24:24.793 You use Fury Halt on Irra.
```
Source: Aetolia log excerpt with explicit target and ability. citeturn29search3

```text
21:33:50.602 H:5995 M:3706 A:4900
```
Source: Aetolia log excerpt illustrating prompt/state snapshot lines. citeturn29search1

```text
15:06:20.915 Equilibrium Used: 4.00 seconds
```
Source: Aetolia log excerpt showing explicit action lockout timing. citeturn32search1

```text
01:15:03.896 There are 3 panacea pills in a stack here.
```
Source: Aetolia log excerpt illustrating room/inventory context metadata. citeturn32search4

```text
00:11:55.172 LOB Zarranik : CURARE
```
Source: Aetolia log excerpt showing a compact “apply venom / action state” line pattern. citeturn32search3

## Mapping to Lua Integration

This section assumes you are building (or extending) a Lua-based combat engine that can (a) ingest events from logs for analysis/training and (b) replay events into a simulation loop.

### Event-to-Lua mapping diagram

```mermaid
flowchart LR
  L[Raw log line] --> P[Lua line parser]
  P -->|event table| B[Event bus / dispatcher]
  B --> D1[onDamage(e)]
  B --> H1[onHeal(e)]
  B --> S1[onStatusApply(e)]
  B --> S2[onStatusRemove(e)]
  B --> R[onResourceSnapshot(e)]
  B --> T[onTiming(e)]
  D1 --> E[Combat state reducer]
  H1 --> E
  S1 --> E
  S2 --> E
  R --> E
  T --> E
  E --> O[State trace + feature export]
```

### Canonical event codes (recommended)

Define a small enum-like set, independent of game:

- `DAMAGE`: numeric loss (hp, limb% or shield values)
- `HEAL`: numeric gain
- `CAST` / `ABILITY_USE`: “You use …” lines with skill/ability extraction
- `APPLY_STATUS` / `REMOVE_STATUS`: afflictions, buffs/defences, stance changes
- `RESOURCE_SNAPSHOT`: HP/MP/etc prompt lines
- `TIMING`: “Balance Used / Equilibrium Used” and similar action-window indicators
- `CONTEXT`: room/location, match arena name, inventory lines, etc.

### Lua parsing and dispatch skeleton

```lua
-- Canonical event dispatcher
local handlers = {
  DAMAGE = function(e) Combat.applyDamage(e.actor, e.target, e.amount, e.damage_type) end,
  HEAL   = function(e) Combat.applyHeal(e.actor, e.target, e.amount) end,
  APPLY_STATUS  = function(e) Combat.applyStatus(e.target, e.status) end,
  REMOVE_STATUS = function(e) Combat.removeStatus(e.target, e.status) end,
  RESOURCE_SNAPSHOT = function(e) Combat.setResources(e.actor, e.resources) end,
  TIMING = function(e) Combat.setCooldown(e.actor, e.timing_kind, e.timing_ms) end,
}

local function dispatch(event)
  local h = handlers[event.etype]
  if h then h(event) end
end

-- Minimal Lua-pattern parser examples
local function parseLine(line, seq)
  -- timestamp HH:MM:SS.mmm prefix
  local ts, rest = line:match("^(%d%d:%d%d:%d%d%.%d%d%d)%s+(.+)$")
  if not ts then return nil end

  -- Health Lost variant
  local amt, dtype = rest:match("^Health%s+Lost:%s+(%d+),?%s*([^,]*)$")
  if amt then
    return {
      seq = seq, ts = ts, etype = "DAMAGE",
      actor = "unknown", target = "you_or_current_target",
      amount = tonumber(amt),
      damage_type = (dtype ~= "" and dtype or nil),
      raw = line,
    }
  end

  -- “You use <skill> <ability> on <target>” (simplify; expand as needed)
  local skill, abil, target = rest:match("^You use ([%w']+)%s+([%w']+)%s+on%s+([%w']+)")
  if skill then
    return {
      seq = seq, ts = ts, etype = "ABILITY_USE",
      actor = "you", target = target,
      skill = skill, ability = abil,
      raw = line,
    }
  end

  -- Equilibrium Used timing
  local secs = rest:match("^Equilibrium Used:%s+(%d+%.?%d*)%s+seconds")
  if secs then
    return {
      seq = seq, ts = ts, etype = "TIMING",
      actor = "you",
      timing_kind = "equilibrium",
      timing_ms = math.floor(tonumber(secs) * 1000),
      raw = line,
    }
  end

  return nil
end

-- Replay driver (stream events)
local function replayLog(lines)
  for i, line in ipairs(lines) do
    local e = parseLine(line, i)
    if e then dispatch(e) end
  end
end
```

### Practical Lua integration notes specific to IRE-style logs

- Many IRE logs contain repeated “prompt-like” snapshots (HP/MP/etc). Treat them as `RESOURCE_SNAPSHOT` events; they are essential for reconstructing damage deltas when “Health Lost” is absent. citeturn29search1turn26view0  
- “Balance Used” / “Equilibrium Used” timers are highly predictive control signals for modeling “can act / cannot act” states. citeturn21view0turn39view0turn32search1  
- If you are able to capture GMCP, store those messages as separate structured events and fuse them during replay; GMCP is specifically designed to transmit character/room/game information “behind the scenes.” citeturn36search5  

## Testing Plan and Timeline

### Testing plan

Testing should be structured around three invariants: **parser correctness**, **ordering correctness**, and **simulation determinism**.

- **Golden tests**: Each of the 10 sample logs above becomes a “golden fixture.” Assert that key patterns parse into expected event types and fields (timestamp, amount, ability name). citeturn21view0turn39view0turn35search0turn32search3  
- **Ordering tests**: Ensure stable ordering for same-timestamp lines using `seq` monotonic indices. Replay should be deterministic.  
- **Schema round-trip**: Store `raw_line` in every parsed event, and verify you can trace an event back to a location in `normalized_text`.  
- **Redaction tests**: Include fixtures with communication lines; ensure your filters remove or hash tells/emails/personal info in accordance with privacy-by-design goals, aligning with the general posture of not sharing personal information on log-sharing services. citeturn38search2turn41view1  
- **Latency feature tests**: If GMCP is captured, verify `Core.Ping` values (where present) are correctly attributed to time windows; otherwise compute timing features from “Balance/Equilibrium Used” lines. citeturn36search5turn32search1turn39view0  

### Timeline (six-week plan)

| Phase | Outcomes | Target duration |
|---|---|---|
| Foundation | Confirm scope of “Runewarden/Dragon” targets; finalize legal posture and redaction rules from ToS/Privacy; set up repo, storage layout, and schema migrations. citeturn41view0turn41view1 | Week 1 |
| Seed corpus | Harvest a seed set from public logs (Ada pastebin + bin host; nogfx as supplemental). Preserve raw + normalized copies; record provenance. citeturn38search2turn36search6 | Week 2 |
| Parser core | Implement timestamp + event classification passes; support at least: DAMAGE/HEAL/ABILITY_USE/APPLY_STATUS/REMOVE_STATUS/RESOURCE_SNAPSHOT/TIMING. Validate against the 10 golden fixtures. citeturn21view0turn39view0turn35search0turn32search3 | Week 3 |
| Enrichment | Add actor/target resolution, fight segmentation, and optional GMCP fusion (if available). Document uncertainty handling for class/role inference. citeturn36search5turn36search0turn36search4 | Week 4 |
| Lua integration | Build replay runner, event bus, and combat-state reducer hooks; emit state traces and summary metrics (TTK, affliction timelines, cooldown usage). | Week 5 |
| Evaluation | Stress test on larger logs; measure parse coverage; identify missing patterns (new affliction strings, defence messages); iterate and finalize documentation. | Week 6 |